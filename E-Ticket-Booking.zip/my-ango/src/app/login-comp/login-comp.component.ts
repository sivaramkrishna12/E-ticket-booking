import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login-comp',
  templateUrl: './login-comp.component.html',
  styleUrls: ['./login-comp.component.css']
})
export class LoginCompComponent implements OnInit {

  constructor(private router:Router) { }
  
  username: string = '';
  password: string = '';
  errorMessage: string = '';

  onLogin() {
    if (this.username === 'remya' && this.password === '123') {
      alert('Login successful!');
      this.router.navigate(['add'])
      // this.errorMessage = '';
    } else {
      alert('Invalid username or password!');
    }
  }

  ngOnInit(): void {
  }

}
