//model booking class

export class Booking {
    id: string;
    firstName: string;
    lastName: string;
    emailId: string;
    phone: string;
    address: string
    source: string;
    destination: string;
    date: string;
    // document:Document;
    // active: boolean;
}